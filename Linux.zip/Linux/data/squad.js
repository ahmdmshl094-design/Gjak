module.exports = {
  active: false,
  phase: "idle", // idle | battle
  round: 0,
  teams: {
    A: null,
    B: null
  }
};
